/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Employee;

import java.awt.image.BufferedImage;

/**
 *
 * @author shawson
 */
public class Doctor extends Employee {
    
    public Doctor(String name, int id, String phoneNum) {
        super(name, id, phoneNum);
    }
}
